import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from groupcot.config import load_config
from groupcot.context import AutoPullLoop, Puller, Store
from groupcot.engine import create_engine
from groupcot.groups import Cyclic, FilterRule, VectorAdd
from groupcot.prompts import PromptSet


def make_group(cfg: dict):
    g = cfg["group"]
    if g["type"] == "cyclic":
        return Cyclic(g["cyclic_n"])
    if g["type"] == "vector":
        return VectorAdd(g["dim"])
    raise ValueError(g["type"])


def make_store(engine, group, count: int = 5) -> Store:
    store = Store(group=group)
    fragments = [
        "Квантовый шум влияет на время декогеренции кубитов.",
        "Криптосистема Пэйе признана устаревшей после квантовых атак.",
        "Гомоморфные схемы позволяют вычислять на зашифрованных данных.",
        "Абелева группа коммутативна: порядок операций не важен.",
        "Обратимые элементы группы позволяют удалять вклад из агрегата.",
    ]
    for i, text in enumerate(fragments):
        store.add(f"node{i}", text, embedding=engine.embed(text))
    return store


def build_filters(filter_mode: str, exclude_langs: list[str]) -> list[FilterRule]:
    rules = []
    for lang in exclude_langs:
        rules.append(FilterRule(
            pipeline="output",
            type="language",
            action="exclude",
            value=lang,
            mode=filter_mode,
        ))
    return rules


def main():
    ap = argparse.ArgumentParser(description="Demo автоподтяга контекста")
    ap.add_argument("--config", default=str(ROOT / "config.yaml"))
    ap.add_argument("--backend", choices=["mock", "llamacpp"], default=None)
    ap.add_argument("--model", default=None, help="путь к GGUF для llamacpp")
    ap.add_argument("--task", default="Объясни связь гомоморфного шифрования и абелевых групп.")
    ap.add_argument("--filter-mode", choices=["text", "logit"], default="text",
                    help="режим фильтрации выхода: text (post-hoc) или logit (logits_processor)")
    ap.add_argument("--exclude-lang", nargs="*", default=[],
                    help="исключить языки из выхода (например: zh en)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    mcfg = cfg["model"]
    backend = args.backend or mcfg["backend"]

    group = make_group(cfg)
    kwargs = {}
    if backend == "mock":
        kwargs = {"embed_dim": getattr(group, "dim", 8)}
    if backend == "llamacpp":
        kwargs = {"model_path": args.model or mcfg["path"], "n_ctx": mcfg["n_ctx"], "n_gpu_layers": mcfg["n_gpu_layers"]}
    engine = create_engine(backend, **kwargs)

    store = make_store(engine, group)
    filters = build_filters(args.filter_mode, args.exclude_lang)

    pull_cfg = cfg["pull"]
    puller = Puller(store, top_k=pull_cfg["top_k"], threshold=pull_cfg["threshold"])
    prompts = PromptSet()
    loop = AutoPullLoop(
        engine, store, puller, group, prompts=prompts,
        max_steps=pull_cfg["max_steps"], pull_every=pull_cfg["every"],
        max_active=pull_cfg["max_active"], filters=filters,
    )

    print(f"backend={backend} group={group.name} filter_mode={args.filter_mode}")
    if filters:
        for f in filters:
            print(f"  filter: [{f.action}] {f.type}={f.value} mode={f.mode}")
    print(f"step grammar:\n{prompts.step_grammar(group)}")
    print(f"final grammar:\n{prompts.final_grammar()}")

    result = loop.run(args.task)
    shown = dict(result)
    h = shown["context"]["h"]
    if len(h) > 300:
        shown["context"]["h"] = h[:300] + f"… (всего {len(h)} симв.)"
    print(json.dumps(shown, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
