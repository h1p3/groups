import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from groupcot.context import AutoPullLoop, Puller, Store
from groupcot.engine import create_engine
from groupcot.grammar.schema import FinalAnswer
from groupcot.groups import Cyclic
from groupcot.prompts import PromptSet


def main():
    group = Cyclic(64)
    steps = [f"element: {i}\nnarrative: шаг {i}\n" for i in range(4)]
    final_json = json.dumps({
        "answer": "ответ",
        "steps": [{"n": 1, "element": "7", "note": "шаг"}],
        "context": {"h": "3", "pulled": ["node0"], "active_count": 1},
    }, ensure_ascii=False)
    engine = create_engine("mock", responses=steps + [final_json], embed_dim=8)
    store = Store(group=group)
    for i in range(5):
        text = f"фрагмент {i}: некоторый факт гипертекста {i}"
        store.add(f"node{i}", text, embedding=engine.embed(text))

    puller = Puller(store, top_k=2, threshold=-1.0)
    prompts = PromptSet()
    loop = AutoPullLoop(
        engine, store, puller, group, prompts=prompts,
        max_steps=4, pull_every=1, max_active=2,
    )

    tasks = [f"задача {i}: какой фрагмент нужен для ответа?" for i in range(6)]
    total_pulls = 0
    total_forgets = 0
    total_active = 0
    invalid = 0

    for task in tasks:
        res = loop.run(task)
        pulls = [e for e in res["context"]["pulled"] if "event" not in e]
        forgets = [e for e in res["context"]["pulled"] if e.get("event") == "forgot"]
        total_pulls += len(pulls)
        total_forgets += len(forgets)
        total_active += res["context"]["active_count"]
        try:
            FinalAnswer.model_validate_json(res["answer"])
        except Exception:
            invalid += 1

    print(json.dumps({
        "tasks": len(tasks),
        "avg_pulls_per_task": round(total_pulls / len(tasks), 2),
        "total_forgets": total_forgets,
        "avg_active_nodes": round(total_active / len(tasks), 2),
        "structurally_invalid_answers": invalid,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
